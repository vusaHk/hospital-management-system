# Hospital-Management-Html
A decent Hospital Management System which is created using Html, css and Bootstrap.

You can check it out from here - https://nirravv.github.io/Hospital-Management-Html/
